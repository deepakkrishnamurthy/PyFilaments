#!/bin/sh
doconce clean
