scitools replace 'from scitools.std import *' 'from matplotlib.pyplot import *' *.py
scitools replace 'import scitools.std as mpl' 'import matplotlib.pyplot as mpl' *.py
