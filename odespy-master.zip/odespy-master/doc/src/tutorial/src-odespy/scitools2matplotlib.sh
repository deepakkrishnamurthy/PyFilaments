scitools replace 'from matplotlib.pyplot import *' 'from scitools.std import *' *.py
scitools replace 'import matplotlib.pyplot as mpl' 'import scitools.std as mpl' *.py
