#!/bin/sh
rm -rf api *~ tmp.out