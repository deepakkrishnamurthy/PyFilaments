# Compile README.do.txt to GitHub-extended Markdown using DocOnce
doconce format pandoc README --github_md
